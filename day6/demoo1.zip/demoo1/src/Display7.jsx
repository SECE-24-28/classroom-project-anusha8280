import { useState } from "react";

const Display7=()=>{
    
     const[student,setStudent]= useState({
        username:"",
        email:""
     })
      function info(e){
        e.preventDefault()
        console.log("my name is: ",username)
     const change=(e)=>{

setStudent((prev)=>{
return ({...prev,
    [e.target.name]:e.target.value
})
})
}
    return(
        <>
        <h1>im from disp7 {student.username} {student.email}</h1>
        <form onSubmit={info}>
           <input onChange={change} name="username" value={student.username}></input>
            <input type="submit" value="click here!!!"></input>
        </form>
        
        </>
    )
}
export default Display7;
