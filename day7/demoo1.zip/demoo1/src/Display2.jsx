import { useState,useRef } from "react"

    const Display2=()=>{
        const[name,setName]=useState("")
        const input=useRef()
         const view=()=>{
            console.log("the data is: ",input.current.value)
            setName(input.current.value)
         }
        return(
           
            <>
            <h1>im from Display2 </h1>
            <h2>input: {input.current?.value}</h2>
           {/*<input type ="text" value={name} onChange={(e)=>{setName(e.target.value)}}></input>
            <button onClick={()=>{setName("")}}>clear</button> */} 
           <input type="text" ref={input}></input>
            <button onClick={view}>click</button>
            </>
        )
    }
  export default Display2