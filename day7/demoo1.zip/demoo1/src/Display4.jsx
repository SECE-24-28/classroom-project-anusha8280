import { useEffect, useState } from "react"
 

const Display4=()=>{
    const[student,setStudent]=useState({
        name:"Itachi Uchiha",
        gender:"male",
        mobile:9876543210
    })
     //const[name,setName]=useState("Itachi Uchiha")
    //const[gender,setGender]=useState("Male")
    //const[mobile,setMobile]=useState(9876543210)
    console.log("the current state:" ,student)
    function updateName(){
        //setStudent( {name:"Sasuke Uchiha"} )
        setStudent((previousData)=>{
            console.log("pre data:............",previousData)
        return({
            ...previousData,name:"Sasuke Uchiha",mobile:1234567890
        })
    })
           
         
    }
    return(
 <>
    <h1>im from display7</h1> 
 <h1>name:{student.name}</h1>
 <h1>gender:{student.gender}</h1>
 <h1>mobile:{student.mobile}</h1>
 <button onClick={updateName}>change name</button>
 </>
    )
       
     
}
export default Display4
 